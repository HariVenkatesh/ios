//
//  AppDelegate.h
//  WebView
//
//  Created by Hari on 19/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

