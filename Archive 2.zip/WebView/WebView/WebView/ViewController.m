//
//  ViewController.m
//  WebView
//
//  Created by Hari on 19/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    _ProgressView.progress = 0.1;
    someFloat = 1;
    timer = [NSTimer scheduledTimerWithTimeInterval: 1
                                             target: self
                                           selector: @selector(updateTimer)
                                           userInfo: nil
                                            repeats: YES];
    
    NSLog(@"%f",_ProgressView.progress);
}

-(void)updateTimer{
    NSLog(@"%d",someFloat);
    
    NSString *fullURL = @"http://202.129.196.131:8085/demo/broilermax/cms/home";
    NSURL *url = [NSURL URLWithString:fullURL];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [_WebViewWebSite loadRequest:requestObj];
    
    if(_loading==NO){
        someFloat += 1;
        _ProgressView.progress = someFloat;
        if(someFloat==3){
            _loading=YES;
            _ProgressView.progress = 1;
            _ProgressView.hidden = YES;
            [timer invalidate];
        }
    }
    
}



@end
