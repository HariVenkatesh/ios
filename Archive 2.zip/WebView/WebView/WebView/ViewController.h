//
//  ViewController.h
//  WebView
//
//  Created by Hari on 19/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIWebViewDelegate>

{
    int someFloat;
    NSTimer *timer;
}

@property (strong, nonatomic) IBOutlet UIWebView *WebViewWebSite;
@property (strong, nonatomic) IBOutlet UIProgressView *ProgressView;
@property(nonatomic, readonly, getter = isLoading) BOOL loading;

@end

