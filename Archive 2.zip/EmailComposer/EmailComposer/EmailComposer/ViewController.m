//
//  ViewController.m
//  EmailComposer
//
//  Created by Hari on 22/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ComposeEmail:(id)sender {
    NSString *EmailTitle = @"Sample Title Test";
    NSString *EmailContent = @"Content of Email";
    NSArray *ToRecipents = [NSArray arrayWithObject:@"harivenkatesh@cgvakindia.com"];
    NSArray *CcRecipents = [NSArray arrayWithObject:@"harivenkatesh@cgvakindia.com"];
    NSArray *BccRecipents = [NSArray arrayWithObject:@"harivenkatesh@cgvakindia.com"];
    
    MFMailComposeViewController *MailCompose = [[MFMailComposeViewController alloc] init];
    MailCompose.mailComposeDelegate = self;
    [MailCompose setSubject:EmailTitle];
    [MailCompose setMessageBody:EmailContent isHTML:NO];
    [MailCompose setToRecipients:ToRecipents];
    [MailCompose setCcRecipients:CcRecipents];
    [MailCompose setBccRecipients:BccRecipents];
    
    // Present mail view controller on screen
    [self presentViewController:MailCompose animated:YES completion:NULL];
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}
@end
