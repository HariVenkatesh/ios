//
//  ViewController.m
//  mapIntegration
//
//  Created by Hari on 15/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    CLLocationManager *locationManager;
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
  
        locationManager = [[CLLocationManager alloc] init];
    
 /*
  Static method of showing the location using latitude and longitude
    
    _mapView.showsUserLocation = YES;
    CLLocationCoordinate2D annotationCoord;
    annotationCoord.latitude = 11.0183;
    annotationCoord.longitude = 76.9725;
    
    MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
    annotationPoint.coordinate = annotationCoord;
    annotationPoint.title = @"Coimbatore";
    annotationPoint.subtitle = @"Your Location";
    [_mapView addAnnotation:annotationPoint];
  */
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)SearchButton:(id)sender {
    
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    
    [locationManager startUpdatingLocation];
    
    /*
     Static method of showing the location using latitude and longitude
   NSLog(@"%@",_SearchBar.text);
    MKUserLocation *userLocation = _mapView.userLocation;
    MKCoordinateRegion region =
    MKCoordinateRegionMakeWithDistance (userLocation.location.coordinate, 11.0183, 76.9725);
    [_mapView setRegion:region animated:NO];
    */
    
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSString *longitude;
    NSString *latitude;
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        longitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        latitude = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
    }
    
    NSLog(@"%@ latitude-",latitude);
    NSLog(@"%@ longitude-",longitude);
    
}

@end
