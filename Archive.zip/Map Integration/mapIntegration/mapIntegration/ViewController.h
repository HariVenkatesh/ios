//
//  ViewController.h
//  mapIntegration
//
//  Created by Hari on 15/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@interface ViewController : UIViewController<CLLocationManagerDelegate>

//@property (strong, nonatomic) CLLocation *currentLocation;
@property (strong, nonatomic) IBOutlet UISearchBar *SearchBar;

- (IBAction)SearchButton:(id)sender;

@end

