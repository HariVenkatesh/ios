//
//  ViewController.m
//  mapintegrationone
//
//  Created by Hari on 16/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"
@import GoogleMobileAds;

@interface ViewController ()
{
    bool pinExists;
    BOOL _bannerIsVisible;
    ADBannerView *_adBanner;
}
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     Static method of showing the location using latitude and longitude
     
     _mapView.showsUserLocation = YES;
     CLLocationCoordinate2D annotationCoord;
     annotationCoord.latitude = 11.0183;
     annotationCoord.longitude = 76.9725;
     
     MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
     annotationPoint.coordinate = annotationCoord;
     annotationPoint.title = @"Coimbatore";
     annotationPoint.subtitle = @"Your Location";
     [_mapView addAnnotation:annotationPoint];
     */
    
//    _bannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
//    _bannerView.delegate = self;
//    
//    locationManager = [[CLLocationManager alloc] init];
    NSLog(@"Google Mobile Ads SDK version: %@", [GADRequest sdkVersion]);
    _BannerView.adUnitID = @"ca-app-pub-9174508952340400/2991666574";
    _BannerView.rootViewController = self;
    [_BannerView loadRequest:[GADRequest request]];
//    _bannerView.adUnitID = @"ca-app-pub-9174508952340400/2991666574";
//    _bannerView.rootViewController = self;
   // [self.bannerView loadRequest:[GADRequest request]];
    
    
}
 /*iAd*/
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
//    _adBanner = [[ADBannerView alloc] init];
//    _adBanner.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)GetLocation:(id)sender {
    
    /*
     Static method of showing the location using latitude and longitude
     NSLog(@"%@",_SearchBar.text);
     MKUserLocation *userLocation = _mapView.userLocation;
     MKCoordinateRegion region =
     MKCoordinateRegionMakeWithDistance (userLocation.location.coordinate, 11.0183, 76.9725);
     [_mapView setRegion:region animated:NO];
     */
    locationManager = [[CLLocationManager alloc] init];
    geoCoder = [[CLGeocoder alloc]init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    [locationManager requestAlwaysAuthorization];
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    
    [locationManager startUpdatingLocation];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        longitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.longitude];
        latitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.latitude];
    }
    _LatLabel.text = latitude;
    _LngLabel.text = longitude;
    
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if (error == nil && [placemarks count] > 0) {
             placemark = [placemarks lastObject];
             states = [NSString stringWithFormat:@"%@",placemark.locality];
             countries=[NSString stringWithFormat:@"%@",placemark.country];
             area=[NSString stringWithFormat:@"%@",placemark.administrativeArea];
             _States.text = states;
             _Countrys.text = countries;
         } else
         {
             NSLog(@"%@", error.debugDescription);
         }
     }];
    
    
    

    MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 }};
    region.center.latitude = [latitude doubleValue];
    region.center.longitude = [longitude doubleValue];
    region.span.longitudeDelta = 0.10f;
    region.span.latitudeDelta = 0.10f;
    [_mapView setRegion:region animated:YES];
    
   
    if(pinExists!=TRUE){
    MKPointAnnotation *add = [[MKPointAnnotation alloc]init];
    add.coordinate = region.center;
    [_mapView addAnnotation:add];
    [locationManager stopUpdatingLocation];
    pinExists = TRUE;
    }else{
        NSLog(@"Annotation Already Exists");
    }
    
}


@end
