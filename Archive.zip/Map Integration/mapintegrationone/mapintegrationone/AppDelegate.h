//
//  AppDelegate.h
//  mapintegrationone
//
//  Created by Hari on 16/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

