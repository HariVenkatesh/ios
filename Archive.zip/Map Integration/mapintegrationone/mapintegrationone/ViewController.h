//
//  ViewController.h
//  mapintegrationone
//
//  Created by Hari on 16/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import <iAd/iAd.h>
#import <GoogleMobileAds/GoogleMobileAds.h>


@interface ViewController : UIViewController <CLLocationManagerDelegate,MKMapViewDelegate,MKAnnotation,GADAdDelegate,GADBannerViewDelegate,ADBannerViewDelegate>
{
    CLGeocoder *geoCoder;
    CLPlacemark *placemark;
    CLLocationManager *locationManager;
    NSString *states,*countries,*area,*latitude,*longitude;
    
}

@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (strong, nonatomic) IBOutlet UILabel *LatLabel;
@property (strong, nonatomic) IBOutlet UILabel *LngLabel;
@property (strong, nonatomic) IBOutlet UILabel *States;
@property (strong, nonatomic) IBOutlet UILabel *Countrys;
//@property (strong, nonatomic) IBOutlet GADBannerView *bannerView;
@property (strong, nonatomic) IBOutlet GADBannerView *BannerView;

- (IBAction)GetLocation:(id)sender;

@end

