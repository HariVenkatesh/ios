//
//  AppDelegate.m
//  BackGroundGeoLocUpdate
//
//  Created by Hari on 22/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsLocationKey]) {
        NSString *WebServiceURL = [NSString stringWithFormat:@"http://202.129.196.131:8085/demo/get_location/webservice.php?function_name=location&location_name=UIApplicationLaunchOptionsLocationKey&lattitude=0.0&longitude=0.0"];
        NSMutableURLRequest *WebServiceRequest = [[NSMutableURLRequest alloc]init];
        [WebServiceRequest setURL:[NSURL URLWithString:WebServiceURL]];
        NSURLResponse *WebServiceResponse;
        NSError *WebServiceError;
        NSData *WebServiceData = [NSURLConnection sendSynchronousRequest: WebServiceRequest returningResponse:&WebServiceResponse error:&WebServiceError];
        
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        locationManager.distanceFilter=kCLDistanceFilterNone;
        [locationManager requestAlwaysAuthorization];
        [locationManager allowsBackgroundLocationUpdates];
        [locationManager startMonitoringSignificantLocationChanges];
    }
    
    
    return YES;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
        NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    longitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.longitude];
    latitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.latitude];
    
    NSString *WebServiceURL = [NSString stringWithFormat:@"http://202.129.196.131:8085/demo/get_location/webservice.php?function_name=location&location_name=AfterTerminationFromBackground&lattitude=%@&longitude=%@",latitude,longitude];
    NSMutableURLRequest *WebServiceRequest = [[NSMutableURLRequest alloc]init];
    [WebServiceRequest setURL:[NSURL URLWithString:WebServiceURL]];
    NSURLResponse *WebServiceResponse;
    NSError *WebServiceError;
    NSData *WebServiceData = [NSURLConnection sendSynchronousRequest: WebServiceRequest returningResponse:&WebServiceResponse error:&WebServiceError];
    
    if(WebServiceData){
        NSLog(@"inserted");
    }else if(WebServiceError){
        NSLog(@"WebServiceError- %@",WebServiceError);
    }

}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSString *WebServiceURL = [NSString stringWithFormat:@"http://202.129.196.131:8085/demo/get_location/webservice.php?function_name=location&location_name=Error&lattitude=0.000&longitude=0.000"];
    NSMutableURLRequest *WebServiceRequest = [[NSMutableURLRequest alloc]init];
    [WebServiceRequest setURL:[NSURL URLWithString:WebServiceURL]];
    NSURLResponse *WebServiceResponse;
    NSError *WebServiceError;
    NSData *WebServiceData = [NSURLConnection sendSynchronousRequest: WebServiceRequest returningResponse:&WebServiceResponse error:&WebServiceError];}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {


}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
