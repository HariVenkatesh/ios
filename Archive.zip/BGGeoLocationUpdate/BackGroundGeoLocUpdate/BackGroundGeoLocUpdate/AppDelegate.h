//
//  AppDelegate.h
//  BackGroundGeoLocUpdate
//
//  Created by Hari on 22/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>{
    NSString *longitude,*latitude;
    CLLocationManager *locationManager;
}

@property (strong, nonatomic) UIWindow *window;

@end

