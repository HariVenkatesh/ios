//
//  ViewController.m
//  BackGroundGeoLocUpdate
//
//  Created by Hari on 22/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)StartGettingLocation:(id)sender {
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
    locationManager.distanceFilter=kCLDistanceFilterNone;
    [locationManager requestAlwaysAuthorization];
    [locationManager allowsBackgroundLocationUpdates];
    geoCoder = [[CLGeocoder alloc]init];
//    [locationManager startUpdatingLocation];
    
    [locationManager startMonitoringSignificantLocationChanges];
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
//    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    longitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.longitude];
    latitude = [NSString stringWithFormat:@"%.4f", currentLocation.coordinate.latitude];
    
    _LatitudeTextBox.text = latitude;
    _LongitudeTextBox.text = longitude;

//NSLog(@"Latitude-%@",latitude);
//NSLog(@"Longitude-%@",longitude);
    
    NSString *WebServiceURL = [NSString stringWithFormat:@"http://202.129.196.131:8085/demo/get_location/webservice.php?function_name=location&location_name=SignificantLocationchange&lattitude=%@&longitude=%@",latitude,longitude];
    NSMutableURLRequest *WebServiceRequest = [[NSMutableURLRequest alloc]init];
    [WebServiceRequest setURL:[NSURL URLWithString:WebServiceURL]];
    NSURLResponse *WebServiceResponse;
    NSError *WebServiceError;
    NSData *WebServiceData = [NSURLConnection sendSynchronousRequest: WebServiceRequest returningResponse:&WebServiceResponse error:&WebServiceError];
    
    if(WebServiceData){
        NSLog(@"inserted");
    }else if(WebServiceError){
        NSLog(@"WebServiceError- %@",WebServiceError);
    }
    
}


@end
