//
//  ViewController.h
//  BackGroundGeoLocUpdate
//
//  Created by Hari on 22/02/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<CLLocationManagerDelegate,MKMapViewDelegate,MKAnnotation>
{
    CLGeocoder *geoCoder;
    CLPlacemark *placemark;
    CLLocationManager *locationManager;
    NSString *states,*countries,*area,*latitude,*longitude;
}
@property (strong, nonatomic) IBOutlet UITextField *LatitudeTextBox;
@property (strong, nonatomic) IBOutlet UITextField *LongitudeTextBox;
@property (strong, nonatomic) IBOutlet MKMapView *MapView;

- (IBAction)StartGettingLocation:(id)sender;

@end

