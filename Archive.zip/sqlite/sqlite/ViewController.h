//
//  ViewController.h
//  sqlite
//
//  Created by Hari on 08/03/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController<UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITextField *EmployeeID;
@property (strong, nonatomic) IBOutlet UITextField *EmployeeName;
@property (strong, nonatomic) IBOutlet UITextField *EmployeeDept;

@property (strong, nonatomic) IBOutlet UILabel *EmpName;
@property (strong, nonatomic) IBOutlet UILabel *EmpDesg;

- (IBAction)InsertButton:(id)sender;
- (IBAction)UpdateButton:(id)sender;
- (IBAction)DeleteButton:(id)sender;
- (IBAction)ViewButton:(id)sender;
- (IBAction)ShowTable:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *LocalDBData;
@property (strong, nonatomic) IBOutlet UITableView *TableViewToShowLocalDBData;
@property (strong, nonatomic) IBOutlet UITableView *StaticCell;

@end

