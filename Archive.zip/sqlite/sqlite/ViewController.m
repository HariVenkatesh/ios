//
//  ViewController.m
//  sqlite
//
//  Created by Hari on 08/03/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
    NSString *databasePath;
    sqlite3 *database;
    sqlite3_stmt *statement;
    NSString *docsDir;
    NSArray *dirPaths;
    NSFileManager *filemgr;
    const char *dbpath;
    NSString *EmployeeIDString;
    NSString *EmployeeNameString;
    NSString *EmployeeDEPTString;
    NSMutableArray *EmployeeArray;
    NSMutableDictionary *EmployeeDictionary;
    
}

@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _LocalDBData =[[UITableView alloc]init];
    [_LocalDBData registerNib:[UINib nibWithNibName:@"cell" bundle:nil]forCellReuseIdentifier:@"Cell"];
    _LocalDBData.delegate = self;
    _LocalDBData.dataSource = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)Alert: (NSString *)message{
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   NSLog(@"OK action");
                               }];
    
    

    
    UIAlertController *EmpFormAlert = [UIAlertController alertControllerWithTitle:@"Login"
                                                                          message:message
                                                                   preferredStyle:UIAlertControllerStyleAlert];
    
    [EmpFormAlert addAction:okAction];
    [self presentViewController:EmpFormAlert animated:YES completion:nil];

    
}

- (IBAction)InsertButton:(id)sender {
    
    
    if(_EmployeeID.text.length!=0){
        
        dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        docsDir = dirPaths[0];
        databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"Employee.db"]];
        
        filemgr = [NSFileManager defaultManager];
        if ([filemgr fileExistsAtPath: databasePath ] == NO)
        {
            dbpath = [databasePath UTF8String];
            if (sqlite3_open(dbpath, &database) == SQLITE_OK)
            {
                char *errMsg;
                const char *sql_stmt = "CREATE TABLE IF NOT EXISTS EMPLOYEE (EMPID INTEGER PRIMARY KEY, EMPNAME TEXT, EMPDEPT TEXT)";
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)!= SQLITE_OK)
                {
                    
                    [self Alert:@"FAILED TO CREATE TABLE"];
                }
                sqlite3_close(database);
            }
            else {
                [self Alert:@"FAILED TO CREATE/OPEN DATABASE"];
            }
        }else{
            
            dbpath = [databasePath UTF8String];
            if (sqlite3_open(dbpath, &database) == SQLITE_OK)
            {
                NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO EMPLOYEE (EMPID,EMPNAME,EMPDEPT) VALUES(\"%@\",\"%@\", \"%@\")",_EmployeeID.text,_EmployeeName.text,_EmployeeDept.text];
                const char *insert_stmt = [insertSQL UTF8String];
                sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
                if (sqlite3_step(statement) == SQLITE_DONE)
                {
                    [self Alert:@"Successfully Data Inserted"];
                    
                }else{
                    
                    [self Alert:@"Data Duplicaton Occured"];
                    
                }
                sqlite3_reset(statement);
            }
        }
        
    }else{
        
        [self Alert:@"Please Enter Employee ID"];
    }
    
    
}

- (IBAction)UpdateButton:(id)sender {

    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"Employee.db"]];
    
    filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        [self Alert:@"NOTABLE"];
    }else{
        dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {

            NSString *UpdateSQL = [NSString stringWithFormat:@"UPDATE EMPLOYEE SET EMPNAME=\"%@\",EMPDEPT=\"%@\" WHERE EMPID=\"%@\"",_EmployeeName.text,_EmployeeDept.text,_EmployeeID.text];
            const char *insert_stmt = [UpdateSQL UTF8String];
            sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
            if (sqlite3_step(statement) == SQLITE_DONE)
            {
                [self Alert:@"Successfully Updated"];
                
            }else{
                
                [self Alert:@"Data Cannot Be Updated" ];
                
            }
            sqlite3_reset(statement);
        }
        }
    
}

- (IBAction)DeleteButton:(id)sender {
    
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"Employee.db"]];
    
    filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        [self Alert:@"NOTABLE"];
    }else{
        dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
        NSString *deleteSQL = [NSString stringWithFormat:@"DELETE FROM EMPLOYEE WHERE EMPID=\"%@\"",_EmployeeID.text];
            const char *insert_stmt = [deleteSQL UTF8String];
            sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
            if (sqlite3_step(statement) == SQLITE_DONE)
            {
                [self Alert:@"Successfully Deleted"];
                
            }else{
                
                [self Alert:@"Data Cannot Be Deleted"];
                
            }
            sqlite3_reset(statement);
        }

    }
    
}

- (IBAction)ViewButton:(id)sender {
    
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"Employee.db"]];
    filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        [self Alert:@"NOTABLE"];
    }else{
        dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            NSString *viewSQL = [NSString stringWithFormat:@"SELECT * FROM EMPLOYEE WHERE EMPID=%@;",_EmployeeID.text];
            const char *insert_stmt = [viewSQL UTF8String];
            
            if (sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL) == SQLITE_OK)
            {
                while (sqlite3_step(statement) == SQLITE_ROW) {
                    
                    NSString *EmployeeNameString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)];
                    
                    NSString *EmployeeDEPTString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)];
                    
                    _EmployeeName.text = EmployeeNameString;
                    _EmployeeDept.text = EmployeeDEPTString;
                    
                }
                
            }else{
                
                [self Alert:@"Data Cannot Be Viewed"];
                
            }
            sqlite3_finalize(statement);
        }
    }
}

- (IBAction)ShowTable:(id)sender {
    
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"Employee.db"]];
    filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        [self Alert:@"NOTABLE"];
    }else{
        dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            NSString *viewSQL = [NSString stringWithFormat:@"SELECT * FROM EMPLOYEE"];
            const char *insert_stmt = [viewSQL UTF8String];
            
            if (sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL) == SQLITE_OK)
            {
                while (sqlite3_step(statement) == SQLITE_ROW) {
                     [EmployeeArray removeAllObjects];
                    EmployeeIDString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)];
                    
                    EmployeeNameString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)];
                    
                    EmployeeDEPTString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)];
                
                    [EmployeeArray addObject:EmployeeIDString];
                    [EmployeeArray addObject:EmployeeNameString];
                    [EmployeeArray addObject:EmployeeDEPTString];
                    [EmployeeDictionary setObject:EmployeeArray forKey:EmployeeIDString];
                   
                }
                //[EmployeeDictionary removeAllObjects];
            }else{
                
                [self Alert:@"Data Cannot Be Viewed"];
                
            }
            sqlite3_finalize(statement);
        }
    }
//    [EmployeeDictionary setObject:EmployeeArray forKey:EmployeeIDString];
//    NSLog(@"EmpDict-%@",[EmployeeDictionary objectForKey:@"773"]);
//    NSLog(@"EmpDict-%@",[EmployeeDictionary objectForKey:@"774"]);
//    NSLog(@"EmpDict-%@",[EmployeeDictionary objectForKey:@"775"]);
//    NSLog(@"EmpDict-%@",[EmployeeDictionary objectForKey:@"776"]);
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return [EmployeeDictionary count];
}

//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    static NSString *simpleTableIdentifier = @"cell";
//    
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
//    
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
//    }
//    
////    cell.EmpName.text = [[EmployeeDictionary valueForKey:@"773"]objectAtIndex:indexPath.row];
////    cell.EmpDesg.text = [[EmployeeDictionary valueForKey:@"773"]objectAtIndex:indexPath.row];
//    return cell;
//}
@end


































