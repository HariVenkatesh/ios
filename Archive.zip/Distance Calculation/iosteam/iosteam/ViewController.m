//
//  ViewController.m
//  iosteam
//
//  Created by Hari on 03/05/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(hideKeyBoard)];
    
    [self.view addGestureRecognizer:tapGesture];

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


-(void)hideKeyBoard {
    [self.view endEditing:YES];
}


- (IBAction)calculateDistance:(id)sender {
    
    [self.view endEditing:YES];
    CLLocation *startLocation = [[CLLocation alloc] initWithLatitude:[_startingPointLat.text floatValue] longitude:[_startingPointLng.text floatValue]];
    CLLocation *endLocation = [[CLLocation alloc] initWithLatitude:[_destinationPointLat.text floatValue] longitude:[_destinationPointLng.text floatValue]];
    
    CLLocationDistance distance = [startLocation distanceFromLocation:endLocation];
    CLLocationDistance KMdistance = [startLocation distanceFromLocation:endLocation]/1000; //for kilometers
   _MilesDistance.text = [NSString stringWithFormat:@"%f",distance * 0.000621371];

    NSLog(@"Distance%f",distance);
    NSLog(@"Kilometers%f",KMdistance);
//NSLog(@"Miles%f",KMdistance/1.60934);
    NSLog(@"Miles%f",distance * 0.000621371);

}


- (IBAction)ResetBtn:(id)sender {
    [self.view endEditing:YES];
    _MilesDistance.text = @"";
    _startingPointLat.text = @"";
    _startingPointLng.text = @"";
    _destinationPointLat.text = @"";
    _destinationPointLng.text = @"";
    
}

- (IBAction)GetCurrentLoc:(id)sender {
    NSLog(@"click");
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];

}



#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{

    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
       longitude = [NSString stringWithFormat:@"%.15f", currentLocation.coordinate.longitude];
       latitude = [NSString stringWithFormat:@"%.15f", currentLocation.coordinate.latitude];
    
    _currentLocLat.text = latitude;
    _currentLocLng.text = longitude;
    

   
}

@end
