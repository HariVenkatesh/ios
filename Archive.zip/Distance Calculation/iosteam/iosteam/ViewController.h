//
//  ViewController.h
//  iosteam
//
//  Created by Hari on 03/05/16.
//  Copyright © 2016 Hari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <CLLocationManagerDelegate>{
    
    CLLocationManager *locationManager;
    NSString *latitude,*longitude;
}

@property (strong, nonatomic) IBOutlet UITextField *startingPointLat;
@property (strong, nonatomic) IBOutlet UITextField *startingPointLng;

@property (strong, nonatomic) IBOutlet UITextField *destinationPointLat;
@property (strong, nonatomic) IBOutlet UITextField *destinationPointLng;

@property (strong, nonatomic) IBOutlet UILabel *MilesDistance;
@property (strong, nonatomic) IBOutlet UILabel *currentLocLat;
@property (strong, nonatomic) IBOutlet UILabel *currentLocLng;

- (IBAction)calculateDistance:(id)sender;

- (IBAction)ResetBtn:(id)sender;
- (IBAction)GetCurrentLoc:(id)sender;

@end

